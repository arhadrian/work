---
title: 
draft: false
tags: 
aliases: 
my-relation: 
An-nastere: 
An-deces: 
nota-data: "{{date:YYYY.MM.DD}}"
---

# date generale

# date biografice

# lucări și contribuții

# domenii DDC

# conexiuni externe
## Internet

## lucrări

## note personale



---
# subsolul notei
---
## referințe și resurse


---
## note de subsol
---


