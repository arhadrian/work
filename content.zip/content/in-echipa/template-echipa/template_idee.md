---
title: 
draft: false
tags:
---
> [!abstract]- antet  
> context::  
> data:: {{date:YYYY.MM.DD}}  
> ora:: {{time:HH:mm}}  
> conexiuni::  
> DDC::  
> ZettelkastenCode::  
> sursa::  
> tags::  


---

# componente externe


# ideea

text


---
# subsolul notei
---
## referințe și resurse


---
## note de subsol
---


