---
title: 
draft: false
tags:
---
> [!abstract]- antet  
> context:: [[content/index|index]]   
> data:: 2024.11.10  
> ora:: 14:13  
> conexiuni::  
> DDC::  
> ZettelkastenCode::  
> sursa::  
> tags::  


---
# componente externe  
  
# ideea  
- *(vom sintetiza într-un microeseu)*  
# componentele  
## T - Teorie  
- nota principală: [[OPeRA T]]  
-   
## U - Urbanism  
- nota principală: [[OPeRA U]]  
-   
## AI - Arhitectură și Arhitectură de Interior  
- nota principală: [[OPeRA AI]]  
-   
## DE - Detaliere pentru Execuție  
- nota principală: [[OPeRA DE]]  
-   
## Materiale  
- nota principală: [[OPeRA M]]  
- bază de cunoștințe care cuprinde și o bază de date cu materialele din DST Lab  


---
# subsolul notei
---
## referințe și resurse


---
## note de subsol
---


