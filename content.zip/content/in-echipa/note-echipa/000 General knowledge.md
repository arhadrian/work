---
title: 
draft: false
tags:
---
> [!abstract]- antet  
> context:: [[o500 DDC]]  
> data:: 2024.11.10  
> ora:: 14:13  
> conexiuni::  
> DDC::  
> ZettelkastenCode::  
> sursa::  
> tags::  #DDC 


---

# componente externe


# sections and subsections
  
000 General knowledge  
001 Knowledge  
[[001.400 Research methodologies]]  
[[001.401 Academic research]]  
001.410 Disciplines  
001.420 Multidisciplinarity and Interdisciplinarity  
[[001.430 Transdisciplinarity and Metadisciplinarity]]  
[[001.450 PKM]]  
001.500 Comparatism  
002 The book  
003 Systems  
003.100 General Systems Theory  
004 Computer science  
[[005 Computer programming]]  
[[006 Special computer methods]]  
[[006.300 Artificial Intelligence]]  
*007 (free)  
008 (free)  
009 (free)*  
  

---  
# subsolul notei  
---  
## referințe și resurse

  
---  
## note de subsol  
---  
  

