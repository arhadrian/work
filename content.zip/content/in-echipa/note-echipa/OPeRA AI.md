---
title: 
draft: false
tags:
---
> [!abstract]- antet  
> context:: [[OPeRA TUAIDEM]]  
> data:: 2024.11.10  
> ora:: 14:13  
> conexiuni::  
> DDC::  
> ZettelkastenCode::  
> sursa::  
> tags::  


---

# componente externe  

  
# OPeRA AI - Arhitectură și Arhitectură de Interior  

text  


---
# subsolul notei
---
## referințe și resurse


---
## note de subsol
---


