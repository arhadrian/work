---
title: 
draft: false
tags:
---
> [!abstract]- antet  
> context:: [[o500 DDC]]  
> data:: 2024.11.10  
> ora:: 14:13  
> conexiuni::  
> DDC::  
> ZettelkastenCode::  
> sursa::  
> tags:: #DDC    


---

# componente externe
  

# sections and subsections
  
142.100 Kantianism and Neo-Kantianism  
[[142.500 Phenomenology]]  
149.900 Structuralism  
149.980 Holism  

  
---  
# subsolul notei  
---  
## referințe și resurse  
  

---  
## note de subsol  
---  
  

