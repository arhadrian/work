---
title: platforma OPeRA - test
draft: false
tags:
---
> [!abstract]- antet  
> context:: __fără context__, pagină de pornire   
> data:: 2024.11.10  
> ora:: 14:13  
> conexiuni::  
> DDC::  
> ZettelkastenCode::  
> sursa::  
> tags::  


---

# componente externe
## primele conexiuni
- [vault publicat pe Internet](https://arhadrian.github.io/work/)
- test de lucru: [[142.500 Fenomenologie temp]]
# sistem personal de gestiune a cunoștințelor - PKMS
realizat în cadrul proiectului [**OPeRA**](https://opera-phd.org/)
![[OPeRA-logo-350.png|200]]
## introducere
Acesta este un posibil punct de **pornire** în structura platformei digitale [OPeRA](https://opera-phd.org/), versiunea 0.1[^1].
## conținut
Principalele **componente** sunt:
- **sistemele PKM**, documentare generală - [[001.450 PKM]]
- **mediateca**, în sistem DDC [[o500 DDC]][^2]
- **platforma** digitală de managementul cunoștințelor, modul în cadrul proiectului [OPeRA](https://opera-phd.org/)
	- date, componente și conexiuni generale - [[platforma OPeRA]]
	- sistemul TUA_IDEM de clasare a informațiilor - [[OPeRA TUAIDEM]]

|    (teorie)    |    (practică)    | (materialitate) |
|:--------------:|:----------------:|:---------------:|
|                |  [[OPeRA U\|U]]  |                 |
| [[OPeRA T\|T]] | [[OPeRA AI\|AI]] | [[OPeRA M\|M]]  |
|                | [[OPeRA DE\|DE]] |                 |


---
# subsolul notei
---
## referințe și resurse


---
## note de subsol
---
[^1]: reprezintă o versiune alpha-testing
[^2]: Dewey Decimal Classification System